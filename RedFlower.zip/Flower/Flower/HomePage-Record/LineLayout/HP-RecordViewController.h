//
//  LineLayoutViewController.h
//  Animations
//
//  Created by YouXianMing on 2017/10/16.
//  Copyright © 2017年 YouXianMing. All rights reserved.
//

#import "NormalTitleController.h"

@interface HP_RecordViewController: NormalTitleController

@end
