//
//  LineLayoutCollectionViewCell.h
//  Animations
//
//  Created by YouXianMing on 2017/10/30.
//  Copyright © 2017年 YouXianMing. All rights reserved.
//

#import "BaseCustomCollectionCell.h"

@interface LineLayoutCollectionViewCell : BaseCustomCollectionCell

@end
