//
//  IconInfoModel.h
//  Test
//
//  Created by YangHQ on 2018/7/13.
//  Copyright © 2018年 JonathanLu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface IconInfoModel : NSObject
@property(strong,nonatomic)NSString *idNum;

@property(strong,nonatomic)NSString *iconName;

@property(strong,nonatomic)NSString *flowerNum;

@property(strong,nonatomic)NSString *time;

@property(strong,nonatomic)NSString *exp;
@end
