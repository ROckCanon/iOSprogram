//
//  WishModel.h
//  smallRedFlower
//
//  Created by yhq on 2018/5/6.
//  Copyright © 2018年 YHQ. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface WishModel : NSObject
@property(strong,nonatomic)NSString *time;

@property(strong,nonatomic)NSString *idNum;

@property(strong,nonatomic)NSString  *wish;

@property(strong,nonatomic)NSString  *flowerNum;

@end
