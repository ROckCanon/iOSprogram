//
//  IconInfoModel.m
//  Test
//
//  Created by YangHQ on 2018/7/13.
//  Copyright © 2018年 JonathanLu. All rights reserved.
//

#import "IconInfoModel.h"

@implementation IconInfoModel

@end
