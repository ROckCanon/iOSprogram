//
//  WishModel.m
//  smallRedFlower
//
//  Created by yhq on 2018/5/6.
//  Copyright © 2018年 YHQ. All rights reserved.
//

#import "WishModel.h"

@implementation WishModel

@end
