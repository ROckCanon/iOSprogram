//
//  UIView+AnimationsListViewController.h
//  Animations
//
//  Created by YouXianMing on 16/3/25.
//  Copyright © 2016年 YouXianMing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (AnimationsListViewController)

+ (UILabel *)animationsListViewControllerNormalHeadLabel;

+ (UILabel *)animationsListViewControllerHeadLabel;

@end
