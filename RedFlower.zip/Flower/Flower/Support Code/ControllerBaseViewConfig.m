//
//  ControllerBaseViewConfig.m
//  BaseStructrue
//
//  Created by YouXianMing on 2017/5/15.
//  Copyright © 2017年 TechCode. All rights reserved.
//

#import "ControllerBaseViewConfig.h"

@implementation ControllerBaseViewConfig

@end
