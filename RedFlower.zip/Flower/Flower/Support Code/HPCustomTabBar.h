//
//  HPCustomTabBar.h
//  Test
//
//  Created by Jonathan Lu on 2018/5/23.
//  Copyright © 2018年 JonathanLu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "HPTabBarView.h"
@interface HPCustomTabBar : UITabBar
@property (nonatomic, strong) HPTabBarView *tabBarView;
@end
