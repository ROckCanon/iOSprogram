//
//  VideoListModel.m
//
//  http://www.cnblogs.com/YouXianMing/
//  https://github.com/YouXianMing
//
//  Copyright (c) YouXianMing All rights reserved.
//


#import "VideoListModel.h"

@implementation VideoListModel

- (void)setValue:(id)value forUndefinedKey:(NSString *)key {
    
    /*  [Example] change property id to productID
     *
     *  if([key isEqualToString:@"id"]) {
     *
     *      self.productID = value;
     *      return;
     *  }
     */    
}

- (void)setValue:(id)value forKey:(NSString *)key {
    
    // ignore null value
    if ([value isKindOfClass:[NSNull class]]) {
        
        return;
    }
    // consumption
    if ([key isEqualToString:@"consumption"] && [value isKindOfClass:[NSDictionary class]]) {
        
        value = [[ConsumptionModel alloc] initWithDictionary:value];
    }

    // provider
    if ([key isEqualToString:@"provider"] && [value isKindOfClass:[NSDictionary class]]) {
        
        value = [[ProviderModel alloc] initWithDictionary:value];
    }

    // playInfo
    if ([key isEqualToString:@"playInfo"] && [value isKindOfClass:[NSArray class]]) {
        
        NSArray        *array     = value;
        NSMutableArray *dataArray = [NSMutableArray array];
        
        for (NSDictionary *dictionary in array) {
            
            PlayInfoModel *model = [[PlayInfoModel alloc] initWithDictionary:dictionary];
            [dataArray addObject:model];
        }
        
        value = dataArray;
    }


    [super setValue:value forKey:key];
}

- (instancetype)initWithDictionary:(NSDictionary *)dictionary {
    
    if ([dictionary isKindOfClass:[NSDictionary class]]) {
        
        if (self = [super init]) {
            
            [self setValuesForKeysWithDictionary:dictionary];
        }
    }
    
    return self;
}

@end

