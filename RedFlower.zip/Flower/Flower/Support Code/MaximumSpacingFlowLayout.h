//
//  MaximumSpacingFlowLayout.h
//  IrregularGridCollectionView
//
//  Created by YouXianMing on 16/8/30.
//  Copyright © 2016年 YouXianMing. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MaximumSpacingFlowLayout : UICollectionViewFlowLayout

@end
