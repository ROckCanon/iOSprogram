//
//  NormalTitleController.h
//  Animations
//
//  Created by YouXianMing on 2017/5/17.
//  Copyright © 2017年 YouXianMing. All rights reserved.
//

#import "BaseCustomViewController.h"

@interface NormalTitleController : BaseCustomViewController

@end
