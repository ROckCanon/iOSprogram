//
//  HomePageTabBarViewController.h
//  KidsGrowDemo
//
//  Created by Jonathan Lu on 2018/5/4.
//  Copyright © 2018年 Jonathan Lu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomePageTabBarViewController : UITabBarController

@end
