//
//  ViewController.m
//  CA_cube
//
//  Created by yhq on 2017/11/19.
//  Copyright © 2017年 yhq. All rights reserved.
//

#import "ViewController.h"

@interface ViewController (){
   //定义一个起点
    CGPoint startpiont;
//transform正方体
    CATransformLayer *cube;
//定义2个float变量
   
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    CATransform3D clt = CATransform3DIdentity;
    CALayer *cube1 = [self cubeWithTransform:clt];
    cube = (CATransformLayer *)cube1;
    [self.view.layer addSublayer:cube1];
    
}

-(CALayer *)faceWithTransForm:(CATransform3D)transform color:(UIColor *)color{
    CALayer *face = [CALayer layer];
    face.frame = CGRectMake(-50,-50, 100, 100);
    face.backgroundColor = color.CGColor;
    face.transform = transform;
    return face;
}
-(CALayer *)cubeWithTransform:(CATransform3D)transform{
    //创建一个容器
    CATransformLayer *cube = [CATransformLayer layer];
    //前
    CATransform3D ct = CATransform3DMakeTranslation(0, 0, 50);
   // CATransform3DMakeTranslation(CGFloat tx, CGFloat ty, CGFloat tz),tz表示与屏幕的距离
    [cube addSublayer:[self faceWithTransForm:ct color:[UIColor redColor]]];
    //后
    CATransform3D hou = CATransform3DMakeTranslation(0, 0, -50);
    [cube addSublayer:[self faceWithTransForm:hou color:[UIColor greenColor]]];
    //右
    CATransform3D up = CATransform3DMakeTranslation(50, 0, 0);
    up = CATransform3DRotate(up, M_PI_2, 0, 1, 0);//以y轴旋转 M_PI_2的角度
    [cube addSublayer:[self faceWithTransForm:up color:[UIColor blueColor]]];
    //左
    ct = CATransform3DMakeTranslation(-50, 0, 0);
    ct = CATransform3DRotate(ct, M_PI_2, 0, 1, 0);
    [cube addSublayer:[self faceWithTransForm:ct color:[UIColor brownColor]]];
    //把它移动到屏幕中央位置
    CGSize containerSize = self.view.bounds.size;
    cube.position = CGPointMake(containerSize.width / 2.0, containerSize.height /2.0);
    
    cube.transform = transform;
    return cube;
    
}
-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    UITouch *touch = [touches anyObject];
    startpiont = [touch locationInView:self.view];
    //返回值表示触摸在view上的位置
    //这里返回的位置是针对view的坐标系的（以view的左上角为原点(0, 0)）
    //调用时传入的view参数为nil的话，返回的是触摸点在UIWindow的位置
}
//一根或者多根手指在view上移动时自动调用view的下面方法（随着手指的移动，会持续调用该方法）
-(void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    UITouch *touch = [touches anyObject];
    CGPoint currentPosition = [touch locationInView:self.view];
    CGFloat deltaX = startpiont.x - currentPosition.x;
    CGFloat deltaY = startpiont.y - currentPosition.y;
    CATransform3D clt = CATransform3DIdentity;
    clt = CATransform3DRotate(clt, M_PI_2 * deltaY /100, 1, 0, 0);   //以x轴作为翻转
   
    clt = CATransform3DRotate(clt, 0 - M_PI_2 * deltaX /100, 0, 1, 0); //以y轴作为翻转
    cube.transform = clt;
}

@end
