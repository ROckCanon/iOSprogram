//
//  AppDelegate.h
//  CA_cube
//
//  Created by yhq on 2017/11/19.
//  Copyright © 2017年 yhq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

