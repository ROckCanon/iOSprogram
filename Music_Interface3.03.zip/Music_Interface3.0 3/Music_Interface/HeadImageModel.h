//
//  HeadImageModel.h
//  Home
//
//  Created by 尹键溶 on 2017/10/1.
//  Copyright © 2017年 st`. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HeadImageModel : NSObject
@property(nonatomic,strong)NSString *randpic;
@property(nonatomic,strong)NSString *code;

//+(void)ModelWithDic:(NSDictionary *)dict;
@end
