//
//  MenueController.swift
//  LeftMenueDemo
//
//  Created by Tony on 2017/6/20.
//  Copyright © 2017年 Tony. All rights reserved.
//

import UIKit


class MenueController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        

        

        
        let btn1 = UIButton(frame: CGRect(x:30, y: 150, width: 50, height: 50))
        btn1.setTitle("消息", for: UIControlState.normal)
        btn1.setTitleColor(UIColor.darkGray, for: UIControlState.normal)
        btn1.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        //btn1.addTarget(self, action: #selector(btnClicked), for: UIControlEvents.touchUpInside)
        btn1.layer.cornerRadius = 20
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: btn1)
        view.addSubview(btn1)
               
        
        let btn2 = UIButton(frame: CGRect(x: 105, y: 150, width: 50, height: 50))
        btn2.setTitle("好友", for: UIControlState.normal)
        btn2.setTitleColor(UIColor.darkGray, for: UIControlState.normal)
        btn2.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        //btn2.addTarget(self, action: #selector(btnClicked), for: UIControlEvents.touchUpInside)
        btn2.layer.cornerRadius = 20
        view.addSubview(btn2)
        
        
        let btn3 = UIButton(frame: CGRect(x: 175, y: 150, width: 50, height: 50))
        btn3.setTitle("换肤", for: UIControlState.normal)
        btn3.setTitleColor(UIColor.darkGray, for: UIControlState.normal)
        btn3.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        //btn3.addTarget(self, action: #selector(btnClicked), for: UIControlEvents.touchUpInside)
        btn3.layer.cornerRadius = 20
        view.addSubview(btn3)
        
        let btn4 = UIButton(frame: CGRect(x: 35, y: 300, width: 50, height: 50))
        btn4.setTitle("夜间", for: UIControlState.normal)
        btn4.setTitleColor(UIColor.darkGray, for: UIControlState.normal)
        btn4.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
       // btn4.addTarget(self, action: #selector(btnClicked), for: UIControlEvents.touchUpInside)
        btn4.layer.cornerRadius = 20
        view.addSubview(btn4)
        
        let btn5 = UIButton(frame: CGRect(x: 105, y: 300, width: 50, height: 50))
        btn5.setTitle("识曲", for: UIControlState.normal)
        btn5.setTitleColor(UIColor.darkGray, for: UIControlState.normal)
        btn5.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        //btn5.addTarget(self, action: #selector(btnClicked), for: UIControlEvents.touchUpInside)
        btn5.layer.cornerRadius = 20
        view.addSubview(btn5)
        
        let btn6 = UIButton(frame: CGRect(x: 175, y: 300, width: 50, height: 50))
        btn6.setTitle("定时", for: UIControlState.normal)
        btn6.setTitleColor(UIColor.darkGray, for: UIControlState.normal)
        btn6.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
        //btn6.addTarget(self, action: #selector(btnClicked), for: UIControlEvents.touchUpInside)
        btn6.layer.cornerRadius = 20
        view.addSubview(btn6)
        
        let btn7 = UIButton(frame: CGRect(x: 35, y: 450, width: 50, height: 50))
        btn7.setTitle("闹钟", for: UIControlState.normal)
        btn7.setTitleColor(UIColor.darkGray, for: UIControlState.normal)
        btn7.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
       // btn7.addTarget(self, action: #selector(btnClicked), for: UIControlEvents.touchUpInside)
        btn7.layer.cornerRadius = 20
        view.addSubview(btn7)
        
        let btn8 = UIButton(frame: CGRect(x: 105, y: 450, width: 50, height: 50))
        btn8.setTitle("设置", for: UIControlState.normal)
        btn8.setTitleColor(UIColor.darkGray, for: UIControlState.normal)
        btn8.backgroundColor = #colorLiteral(red: 1, green: 1, blue: 1, alpha: 1)
       // btn8.addTarget(self, action: #selector(btnClicked), for: UIControlEvents.touchUpInside)
        btn8.layer.cornerRadius = 20
        view.addSubview(btn8)
        
        
        
        let imageView1 = UIImageView(image:UIImage(named:"icon-1"))
        imageView1.frame = CGRect(x:40, y: 110, width: 40, height: 40)
        self.view.addSubview(imageView1)
        
        let imageView2 = UIImageView(image:UIImage(named:"icon-2"))
        imageView2.frame = CGRect(x: 110, y: 110, width: 40, height: 40)
        self.view.addSubview(imageView2)
        
        let imageView3 = UIImageView(image:UIImage(named:"icon-3"))
        imageView3.frame = CGRect(x: 180, y: 110, width: 40, height: 40)
        self.view.addSubview(imageView3)
        
        let imageView4 = UIImageView(image:UIImage(named:"icon-4"))
        imageView4.frame = CGRect(x: 40, y: 260, width: 40, height: 40)
        self.view.addSubview(imageView4)

        let imageView5 = UIImageView(image:UIImage(named:"icon-5"))
        imageView5.frame = CGRect(x: 110, y: 260, width: 40, height: 40)
        self.view.addSubview(imageView5)
        
        let imageView6 = UIImageView(image:UIImage(named:"icon-6"))
        imageView6.frame = CGRect(x: 180, y: 260, width: 40, height: 40)
        self.view.addSubview(imageView6)
        
        let imageView7 = UIImageView(image:UIImage(named:"icon-7"))
        imageView7.frame = CGRect(x: 40, y: 410, width: 40, height: 40)
        self.view.addSubview(imageView7)
        
        let imageView8 = UIImageView(image:UIImage(named:"icon-8"))
        imageView8.frame = CGRect(x: 110, y: 410, width: 40, height: 40)
        self.view.addSubview(imageView8)
        


    }
    
//    func btnClicked() {
//        
//        let drawer = rootViewController()
//        drawer.showHome()
//        
//        let tab = rootViewController().rootViewController as TabBarController
//        let navController = tab.viewControllers![tab.selectedIndex] as! NavigationController
//        navController.pushViewController(TestController(), animated: true)
//    }
}
