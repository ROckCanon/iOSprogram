//
//  MusicView.h
//  Home
//
//  Created by 尹键溶 on 2017/10/3.
//  Copyright © 2017年 st`. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Song_info.h"
#import <AVFoundation/AVFoundation.h>
@interface MusicView : UIView
//音乐用AvAudio
@property(nonatomic,strong)__block AVPlayer* mymusic;

//歌手的名称
@property (weak, nonatomic) IBOutlet UILabel *SingerName;
//歌手的照片
@property (weak, nonatomic) IBOutlet UIImageView *singerImageView;
//总共时长
@property (weak, nonatomic) IBOutlet UILabel *MusicTime;

@property(nonatomic,strong)NSString* song_id;
@property(nonatomic,strong)Song_info *Info;
+(instancetype)SongIDWithMusicView:(NSString *)ID;//音乐ID

@end
