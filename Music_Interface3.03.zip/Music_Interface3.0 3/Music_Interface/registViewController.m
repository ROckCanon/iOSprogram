//
//  registViewController.m
//  Music_Interface
//
//  Created by TonyStark on 2017/9/29.
//  Copyright © 2017年 TonyStark. All rights reserved.
//

#import "registViewController.h"
#import <AVOSCloud/AVOSCloud.h>
#import "MovieController.h"
#import "HomeViewController.h"
#import "MeViewController.h"
#import "FindViewController.h"
@class MovieController;

//@protocol TextFieldDelegate <UITextFieldDelegate>
//@required
//-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField;
//-(BOOL)textFieldShouldReturn:(UITextField *)textField;

//@end

@interface registViewController()
//{
//    MovieController *_movieController;
//    registViewController *setRegist;
//    
//}

//@property(strong,nonatomic)UITextField *userNameField;
//@property(strong,nonatomic)UITextField *passwordField;
//@property(strong,nonatomic)UITextField *emailTextField;
@property(strong,nonatomic)NSString *userName;
@property(strong,nonatomic)NSString *password;
@property(strong,nonatomic)NSString *email;
//@property(assign,nonatomic)id <TextFieldDelegate>delegate;
@end

@implementation registViewController
-(void)viewDidLoad{
    [super viewDidLoad];
  
//    
//    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 500, 500)];
//    label.backgroundColor = [UIColor blueColor];
//    label.text = @"昂昂昂";
//    [self.view addSubview:label];
   // [self registName];
    //registViewController *controller = [[registViewController alloc]init];
    //self.view.window.rootViewController = controller;
  //  registViewController *newContrcl = [[registViewController alloc]init];
   // self.inputViewController = newContrcl;
    //newContrcl =self;
   // self.view.window.rootViewController = newContrcl;
    [self registName];
    [self registPassword];
    [self registEmail];
    [self registButton];
    self.view.backgroundColor = [UIColor whiteColor];
    
//    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(resi) name:AVPlayerItemTimeJumpedNotification object:self.player];//进入按钮监听

   // self.view.backgroundColor = [UIColor redColor]
//    self.usernameTextField = [[UITextField alloc]initWithFrame:CGRectMake(100, 100, 100, 100)];
//    self.usernameTextField.backgroundColor = [UIColor blueColor];
//    self.usernameTextField.textAlignment = NSTextAlignmentLeft;
//    self.usernameTextField.placeholder = @"name";
//    self.usernameTextField.alpha = 1;
//    self.usernameTextField.borderStyle = UITextBorderStyleLine;
//    self.usernameTextField.layer.cornerRadius = 8.0f;                                       //cornerRadius =8.0f;
//    self.usernameTextField.layer.masksToBounds=YES;
//    self.usernameTextField.layer.borderWidth= 1.0f;
//    [self.view didAddSubview:self.usernameTextField];

    
    
    
    //[self didReceiveMemoryWarning];
//    _movieController.registBlock = ^(registViewController *registcontrol){
//        
//          UIViewController *newcontrol = [[UIViewController alloc]init];
//        newcontrol = registcontrol;
//    
//        newcontrol.view.backgroundColor = [UIColor blueColor];
//        setRegist.view.window.rootViewController = registcontrol;
//        
//       
//        
//    };
//    UIView *newView = [[UIView alloc]initWithFrame:[UIScreen mainScreen].bounds];
//    [self.view addSubview:newView];
//    newView.backgroundColor = [UIColor redColor];
//    self.usernameTextField = [[UITextField alloc]initWithFrame:CGRectMake(114, 187, 155, 30)];
//    self.usernameTextField.backgroundColor = [UIColor blueColor];
//    [newView addSubview:self.passwordTextFied];
  //  self.view.backgroundColor = [UIColor blueColor];
    
        //        self.view.window.rootViewController = registcontrol;
    }

-(void)registName{
      UITextField *userNameField = [[UITextField alloc]initWithFrame:CGRectMake(114, 187, 155, 30)];
    //   userNameField = [[UITextField alloc]initWithFrame:CGRectMake(100, 100, 100, 100)];
       // userNameField.backgroundColor = [UIColor blueColor];
        userNameField.textAlignment = NSTextAlignmentLeft;
        userNameField.placeholder = @"name";
        userNameField.alpha = 1;
        userNameField.borderStyle = UITextBorderStyleLine;
        userNameField.layer.cornerRadius = 8.0f;                                       //cornerRadius =8.0f;
        userNameField.layer.masksToBounds=YES;
        userNameField.layer.borderWidth= 1.0f;
    [userNameField addTarget:self action:@selector(textFieldEnd:) forControlEvents:UIControlEventEditingDidEnd];
      //  [userNameField setDelegate:self.delegate];
    
  //  [userNameField addTarget:self action:<#(nonnull SEL)#> forControlEvents:<#(UIControlEvents)#>];
      //self.userName = userNameField.text;
    
    
        [self.view addSubview:userNameField];

    
//    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 500, 500)];
//    label.backgroundColor = [UIColor blueColor];
//    label.text = @"昂昂昂";
//    [self.view addSubview:label];
     // return userNameField.text;
}


-(void)textFieldEnd:(id)sender{
    UITextField *field = (UITextField *)sender;
    self.userName = field.text;
}




-(void)registPassword{
    UITextField *passwordField = [[UITextField alloc]initWithFrame:CGRectMake(114, 262, 155, 30)];
    passwordField.alpha = 1;
    passwordField.borderStyle = UITextBorderStyleLine;
    passwordField.placeholder = @"password";
    passwordField.secureTextEntry = YES;
    //passwordField.textColor = [UIColor whiteColor];
    passwordField.keyboardType = UIKeyboardTypeNumberPad;
   // [self.player removeObserver:self forKeyPath:AVPlayerItemTimeJumpedNotification];
    passwordField.layer.cornerRadius=8.0f;
    passwordField.layer.masksToBounds=YES;
    passwordField.layer.borderWidth= 1.0f;
   // self.password = passwordField.text;
    [self.view addSubview:passwordField];
    [passwordField addTarget:self action:@selector(textFieldPass:) forControlEvents:UIControlEventEditingDidEnd];
    
}
-(void)textFieldPass:(id)sender{
    UITextField *field2 = (UITextField *)sender;
    self.password = field2.text;
}

//email：
-(void)registEmail{
    UITextField *emailField = [[UITextField alloc]initWithFrame:CGRectMake(114, 337, 155, 30)];
    emailField.textAlignment = NSTextAlignmentLeft;
    emailField.placeholder = @"E-mail";
    emailField.alpha = 1;
    emailField.borderStyle = UITextBorderStyleLine;
    emailField.layer.cornerRadius = 8.0f;                                       //cornerRadius =8.0f;
    emailField.layer.masksToBounds=YES;
    emailField.layer.borderWidth= 1.0f;
  //  self.email = emailField.text;
    [self.view addSubview:emailField];
    [emailField addTarget:self action:@selector(textFieldEmail:) forControlEvents:UIControlEventEditingDidEnd];
}


-(void)textFieldEmail:(id)sender{
    UITextField *field3 = (UITextField *)sender;
    self.email = field3.text;
}
//    =     self.title = @"注册";

  //  self.view.backgroundColor = [UIColor whiteColor];
    
    //self.registView = [UIColor whiteColor];
    



//-(void)registUsername
//{
//    self.usernameTextField = [[UITextField alloc]initWithFrame:CGRectMake(100, 100, 100, 100)];
//    self.usernameTextField.backgroundColor = [UIColor blueColor];
//    self.usernameTextField.textAlignment = NSTextAlignmentLeft;
//    self.usernameTextField.placeholder = @"name";
//    self.usernameTextField.alpha = 1;
//    self.usernameTextField.borderStyle = UITextBorderStyleLine;
//    self.usernameTextField.layer.cornerRadius = 8.0f;                                       //cornerRadius =8.0f;
//    self.usernameTextField.layer.masksToBounds=YES;
//    self.usernameTextField.layer.borderWidth= 1.0f;
//    [self.view didAddSubview:self.usernameTextField];
//
//    
//}
-(void)registButton{
    UIButton *registButton = [[UIButton alloc]initWithFrame:CGRectMake(105 , 412, 180, 30)];
    //    enterButton.frame = CGRectMake(127, 356, 120, 30);
    registButton.layer.borderWidth = 1;
    registButton.layer.cornerRadius = 24;
    registButton.layer.borderColor = [UIColor blackColor].CGColor;
    // enterButton.backgroundColor = [UIColor greenColor];
    [registButton setTitle:@"注册并登陆" forState:UIControlStateNormal];
    [registButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    //[enterButton setImage:[UIImage imageNamed:@"buttongreen"] forState:UIControlStateNormal];
    //[enterButton setBackgroundImage:[UIImage imageNamed:@"buttongreen"] forState:UIControlStateNormal];
    registButton.alpha = 0.5;
    
    [self.view addSubview:registButton];
    [registButton addTarget:self action:@selector(setregistButton) forControlEvents:UIControlEventTouchUpInside];
   // [NSNotificationCenter defaultCenter]addObserver:self selector:@selector(setregistButton) name: object:<#(nullable id)#>
    //[self setregistButton];
   
    

}
-(void)setregistButton
{
    NSLog(@"登陆啦");
  //  NSLog(@"15651616   %@ \n",self.userName);
//    NSString *usernam = self.userNameField.text;
//    NSString *password = self.passwordField.text;
//    NSString *email = self.emailTextField.text;
    NSLog(@"%@\n%@\n%@\n",self.email,self.password,self.userName);
    if (self.userName && self.password && self.email) {
        AVUser *user = [AVUser user];
        user.username = self.userName;
        user.password = self.password;
        user.email = self.email;
        
        [user signUpInBackgroundWithBlock:^(BOOL succeeded,NSError *error){
            if (succeeded) {
              //  [self performSegueWithIdentifier:@"fromSignUpToProducts" sender:nil];
                //[self performSegueWithIdentifier:<#(nonnull NSString *)#> sender:<#(nullable id)#>]
                NSLog(@"注册成功，请稍后 ");
                //创建主页controller
                HomeViewController *home = [[HomeViewController alloc]init];
                home.title = @"首页";
                home.tabBarItem = [[UITabBarItem alloc]initWithTitle:@"首页" image:[UIImage imageNamed:@"sun_set_126px_1174751_easyicon.net"] selectedImage:[UIImage imageNamed:@"sun_set_126px_1174751_easyicon.net"]];
                
                //创建tabarcontroller
                UITabBarController *tab = [[UITabBarController alloc]init];
                //初始化navigation 使home成为根视图后把navigation加入到tabbar中
                UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:home];
                [tab addChildViewController:nav];
                
                //创建搜索Controller
                FindViewController *find = [[FindViewController alloc]init];
                find.title = @"搜索";
                find.tabBarItem = [[UITabBarItem alloc]initWithTitle:@"搜索" image:[UIImage imageNamed:@"search_engine_783px_1207845_easyicon.net"] selectedImage:[UIImage imageNamed:@"search_engine_783px_1207845_easyicon.net"]];
                UINavigationController *navFind = [[UINavigationController alloc]initWithRootViewController:find];
                [tab addChildViewController:navFind];
                
                
                //创建Me的controller
                MeViewController *me = [[MeViewController alloc]init];
                me.title = @"我的音乐";
                me.tabBarItem = [[UITabBarItem alloc]initWithTitle:@"我的音乐" image:[UIImage imageNamed:@"head_set_199px_1189541_easyicon.net"] selectedImage:[UIImage imageNamed:@"head_set_199px_1189541_easyicon.net"]];
                UINavigationController *navMe = [[UINavigationController alloc]initWithRootViewController:me];
                [tab addChildViewController:navMe];
                self.view.window.rootViewController = tab;
                //appDelegate.window.rootViewController = tab;

            }else{
                NSLog(@"注册失败 %@",error);
            }
        }];
    }
}


@end
