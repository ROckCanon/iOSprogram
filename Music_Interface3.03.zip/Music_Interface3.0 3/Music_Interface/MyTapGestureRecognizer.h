//
//  MyTapGestureRecognizer.h
//  Home
//
//  Created by 尹键溶 on 2017/10/2.
//  Copyright © 2017年 st`. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyTapGestureRecognizer : UITapGestureRecognizer

@property(nonatomic,assign)int *tag;


@property(nonatomic,strong)NSString *songID;

@property(nonatomic,strong)NSString *ImageURL;
@end
