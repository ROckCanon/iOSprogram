//
//  MovieController.m
//  Music_Interface
//
//  Created by TonyStark on 2017/9/24.
//  Copyright © 2017年 TonyStark. All rights reserved.
//

#import "MovieController.h"
//#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>
#import <AVKit/AVKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import <QuartzCore/QuartzCore.h>
#import "registViewController.h"
//#import "registViewController.h"
#import "HomeViewController.h"
#import "MeViewController.h"
#import "FindViewController.h"
//@class HomeController;


@interface MovieController()
@property(strong,nonatomic)AVPlayerViewController *playerController;
@property(strong,nonatomic)AVPlayer *player;
//@property(strong,nonatomic)registViewController *registCtrl;
//@property(strong,nonatomic)NSString *urlstring;
//@property(strong,nonatomic)UINavigationController *nagc;
//@property(nonatomic,strong)UIView *home;
//@property(strong,nonatomic)AVPlayerLayer *avLayer;

@end

@implementation MovieController
-(void)viewDidLoad{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self setupVideoPlayer];
    [self Listen];
    [super viewDidLoad];
    //UINavigationController
    
    AVObject *testObject = [AVObject objectWithClassName:@"TestObject"];
    [testObject setObject:@"bar" forKey:@"foo"];
    [testObject save];
    [AVOSCloud setAllLogsEnabled:YES];//开启调试日志
  
}
//监听音乐是否播放完成
-(void)Listen{
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(MyLabel) name:AVPlayerItemDidPlayToEndTimeNotification object:self.player];
//    
//    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(MyLabel2) name:AVPlayerItemTimeJumpedNotification object:self.player];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(setuploginView) name:AVPlayerItemTimeJumpedNotification object:self.player];//进入按钮监听
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(setupPersonname) name:AVPlayerItemTimeJumpedNotification object:self.player];//进入按钮监听
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(setupPassword) name:AVPlayerItemTimeJumpedNotification object:self.player];//进入按钮监听

    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(playbackFinished) name:AVPlayerItemDidPlayToEndTimeNotification object:self.player];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(registerButton) name:AVPlayerItemTimeJumpedNotification object:self.player];//进入按钮监听
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(forgotPassword) name:AVPlayerItemTimeJumpedNotification object:self.player];//进入按钮监听

}



-(void)setuploginView
{
    if(![self.view viewWithTag:11]){
        UIButton *enterButton = [[UIButton alloc]initWithFrame:CGRectMake(105 , 330, 180, 30)];
        //    enterButton.frame = CGRectMake(127, 356, 120, 30);
        enterButton.layer.borderWidth = 1;
        enterButton.layer.cornerRadius = 24;
        enterButton.layer.borderColor = [UIColor whiteColor].CGColor;
        // enterButton.backgroundColor = [UIColor greenColor];
        [enterButton setTitle:@"登陆" forState:UIControlStateNormal];
        //[enterButton setImage:[UIImage imageNamed:@"buttongreen"] forState:UIControlStateNormal];
        //[enterButton setBackgroundImage:[UIImage imageNamed:@"buttongreen"] forState:UIControlStateNormal];
        enterButton.alpha = 0.5;
        enterButton.tag=11;
        [self.view addSubview:enterButton];
        
        
        [enterButton addTarget:self action:@selector(judgeLogin) forControlEvents:UIControlEventTouchUpInside];
    }
    [self.player removeObserver:self forKeyPath:AVPlayerItemTimeJumpedNotification ];
    
   }
-(void)judgeLogin{
    NSLog(@"jin ru la");
    NSString *username = self.uernameTextField.text;
    NSString *password = self.passwordTextFied.text;
    
    //  [enterButton addTarget:self action:@selector(loginAnotherview) forControlEvents:UIControlEventTouchUpInside];
    if (username && password) {
        //这里还需要再修改
        [AVUser logInWithUsernameInBackground:username password:password block:^(AVUser *user,NSError *errow)
         {
             if (errow) {
                 UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"提示" message:@"用户名或密码提交错误" preferredStyle:UIAlertControllerStyleAlert];
                 [alert addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleCancel handler:nil]];
                 [self presentViewController:alert animated:YES completion:nil];
             }else{
                 [self loginAnotherview];
                 //[enterButton addTarget:self action:@selector(loginAnotherview) forControlEvents:UIControlEventTouchUpInside];
                // [self performSegueWithIdentifier:@"fromSignUpToProducts" sender:nil];
             }
         }];
    }

}



-(void)loginAnotherview
{
    
    //创建主页controller
    HomeViewController *home = [[HomeViewController alloc]init];
    home.title = @"首页";
    home.tabBarItem = [[UITabBarItem alloc]initWithTitle:@"首页" image:[UIImage imageNamed:@"sun_set_126px_1174751_easyicon.net"] selectedImage:[UIImage imageNamed:@"sun_set_126px_1174751_easyicon.net"]];
    
    //创建tabarcontroller
    UITabBarController *tab = [[UITabBarController alloc]init];
    //初始化navigation 使home成为根视图后把navigation加入到tabbar中
    UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:home];
    [tab addChildViewController:nav];
    
    //创建搜索Controller
    FindViewController *find = [[FindViewController alloc]init];
    find.title = @"搜索";
    find.tabBarItem = [[UITabBarItem alloc]initWithTitle:@"搜索" image:[UIImage imageNamed:@"search_engine_783px_1207845_easyicon.net"] selectedImage:[UIImage imageNamed:@"search_engine_783px_1207845_easyicon.net"]];
    UINavigationController *navFind = [[UINavigationController alloc]initWithRootViewController:find];
    [tab addChildViewController:navFind];
    
    
    //创建Me的controller
    MeViewController *me = [[MeViewController alloc]init];
    me.title = @"我的音乐";
    me.tabBarItem = [[UITabBarItem alloc]initWithTitle:@"我的音乐" image:[UIImage imageNamed:@"head_set_199px_1189541_easyicon.net"] selectedImage:[UIImage imageNamed:@"head_set_199px_1189541_easyicon.net"]];
    UINavigationController *navMe = [[UINavigationController alloc]initWithRootViewController:me];
    [tab addChildViewController:navMe];
    self.view.window.rootViewController = tab;
//    NSLog(@"jin ru la ");
//    HomeController *homePage = [[HomeController alloc]init];
    //self.view.window.rootViewController = homePage;
//    homePage.title = @"主界面";
    

    
}

-(void)setupPersonname
{
    if(![self.view viewWithTag:12]){
        self.uernameTextField = [[UITextField alloc]initWithFrame:CGRectMake(114, 187, 155, 30)];
        self.uernameTextField.alpha = 1;
        self.uernameTextField.borderStyle = UITextBorderStyleLine;
        [self.view addSubview:self.uernameTextField];
        self.uernameTextField.placeholder = @"name";
        //text1.layer.borderColor = [[UIColor clearColor]CGColor];
        self.uernameTextField.layer.cornerRadius = 8.0f;                                       //cornerRadius =8.0f;
        self.uernameTextField.layer.masksToBounds=YES;
        self.uernameTextField.layer.borderWidth= 1.0f;
        //text1.tintColor = [UIColor clearColor];
        //    if (text1 != nil) {
        //        text1.placeholder = nil;
        //    }
        //    if (text1 = nil) {
        //        text1.placeholder = nil;
        //    }
        self.uernameTextField.textColor = [UIColor whiteColor];
        self.uernameTextField.keyboardType = UIKeyboardTypeNumberPad;
        self.uernameTextField.tag=12;

    }
        [self.player removeObserver:self forKeyPath:AVPlayerItemTimeJumpedNotification];

    
}
-(void)setupPassword
{
    if(![self.view viewWithTag:13]){
        self.passwordTextFied = [[UITextField alloc]initWithFrame:CGRectMake(114, 262, 155, 30)];
        self.passwordTextFied.alpha = 1;
        self.passwordTextFied.borderStyle = UITextBorderStyleLine;
        [self.view addSubview:self.passwordTextFied];
        self.passwordTextFied.placeholder = @"password";
        self.passwordTextFied.secureTextEntry = YES;
        self.passwordTextFied.textColor = [UIColor whiteColor];
        self.passwordTextFied.keyboardType = UIKeyboardTypeNumberPad;
        [self.player removeObserver:self forKeyPath:AVPlayerItemTimeJumpedNotification];
        self.passwordTextFied.layer.cornerRadius=8.0f;
        self.passwordTextFied.layer.masksToBounds=YES;
        self.passwordTextFied.layer.borderWidth= 1.0f;
        self.passwordTextFied.tag= 13;

    }
   [self.player removeObserver:self forKeyPath:AVPlayerItemTimeJumpedNotification];

}
-(void)registerButton
{
    if(![self.view viewWithTag:14]){
        UIButton *buttonreg = [[UIButton alloc]initWithFrame:CGRectMake(10, 500, 150, 10)];
        [buttonreg setTitle:@"注册吧!" forState:UIControlStateNormal];
        buttonreg.alpha = 1;
        buttonreg.layer.borderColor = [UIColor blueColor].CGColor;
        [self.view addSubview:buttonreg];
        [self.player removeObserver:self forKeyPath:AVPlayerItemTimeJumpedNotification];
        [buttonreg addTarget:self action:@selector(registIn) forControlEvents:UIControlEventTouchUpInside];

    }
    
    //[buttonreg addTarget:<#(nullable id)#> action:<#(nonnull SEL)#> forControlEvents:<#(UIControlEvents)#>]
}
//
-(void)registIn
{
    NSLog(@"注册啦");
    registViewController *registCtrl = [[registViewController alloc]init];
   // [nagc popViewControllerAnimated:self.playerController];
   // UINavigationController *nagc = [[UINavigationController alloc]initWithRootViewController:registCtrl];
   // UINavigationController *nagc = [[UINavigationController alloc]init];
    [self.navigationController pushViewController:registCtrl animated:YES];
    //registCtrl.view.backgroundColor = [UIColor blueColor];
    registCtrl.title = @"注册";
   // _registCtrl = [[RegistController alloc]init];
  //  self.view.window.rootViewController = _registCtrl;
 //   registViewController *registCtrl = [[registViewController alloc]init];
    //self.registBlock = [[registViewController alloc]init];
    //self.view.window.rootViewController = registCtrl;
//    if (self.registBlock != nil) {
//        self.registBlock(registCtrl);
//    }
    
    
    //registCtrl.title = @"注册";
    //    UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(100, 100, 150, 100)];
    //    button.backgroundColor = [UIColor blueColor];
    //    [registCtrl.view addSubview:button];
    
    
    
}



-(void)forgotPassword
{
    if(![self.view viewWithTag:15]){
        NSLog(@"忘记密码");
        UIButton *buttonfog = [[UIButton alloc]initWithFrame:CGRectMake(220, 500, 150, 10)];
        [buttonfog setTitle:@"忘记密码？" forState:UIControlStateNormal];
        buttonfog.tag = 15;
        [self.view addSubview:buttonfog];
    }

   [self.player removeObserver:self forKeyPath:AVPlayerItemTimeJumpedNotification];

}

-(void)setupVideoPlayer
{
    //self.player = [[AVPlayer alloc]initWithURL:_movieURL];
    NSString *path = [[NSBundle mainBundle]pathForResource:@"bofangyuan.mp4" ofType:nil];
    
    _sourceMobieURL = [NSURL fileURLWithPath:path];
    
    //self.playerController.player = [[AVPlayer alloc]initWithURL:_sourceMobieURL];
    self.playerController = [[AVPlayerViewController alloc]init];
    //self.playerController.delegate = self;
    self.playerController.player = [AVPlayer playerWithURL:_sourceMobieURL];
    
    self.playerController.view.frame  = [UIScreen mainScreen].bounds;
    
    self.playerController.showsPlaybackControls = NO;
    
    self.playerController.view.backgroundColor = [UIColor greenColor];
    
    [self.view addSubview:self.playerController.view];
    
    self.playerController.view.alpha = 0.7;
    //[self addChildViewController:self.playerController];
    
    [self.playerController.player play];
    
//    AVPlayerLayer *playerLayer = [AVPlayerLayer playerLayerWithPlayer:self.player];
//    
//    playerLayer.frame =   [UIScreen mainScreen].bounds;
//    
//    playerLayer.backgroundColor = [UIColor greenColor].CGColor;
    
//     [self.view.layer addSublayer:playerLayer];
    
    //[self.player play];
    
//  
//    if ( == AVPlayerTimeControlStatusPaused || statuss == AVPlayerTimeControlStatusWaitingToPlayAtSpecifiedRate) {
//        [self.player play];
    
    
    
  //  AVPlayerStatus playstatus = [self.player status];
    
    //if (playstatus == AVPlayerStatusReadyToPlay || playstatus == AVPlayerStatusFailed || playstatus == AVPlayerStatusUnknown) {
    //[self.player play];
}

- (void)playbackFinished
{
    
    NSLog(@"MP4文件读完了");
    [self.playerController.player seekToTime:CMTimeMake(0, 1)];
      self.playerController.player = [[AVPlayer alloc]initWithURL:_sourceMobieURL];
        [self.playerController.player play];

//   AVPlayerStatus playstatus = [self.player status];
//       playstatus = AVPlayerStatusReadyToPlay;
//    [self.playerController.player play];
    
        
     
     
        
}
    

    //[self.playerController.view setFrame:[UIScreen mainScreen].bounds];
    
//    self.playerController.view.alpha = 0;
//    [UIView animateWithDuration:3 animations:^{
//        self.playerController.view.alpha = 1;
//        [self.player play];
    
        //_avLayer = [AVPlayerLayer playerLayerWithPlayer:_player];
//    }
//     
//     ];
//-(void)playbackStateChanged
//    {
//        AVPlayerStatus playState = [self.  ]
//    }
    //self.player.rate = 1.0;
    
   // [self.player play];
    
//    self.player = [[MPMoviePlayerController alloc]initWithContentURL:_movieURL];
//    [self.view addSubview:self.player.view];
//    self.player.shouldAutoplay = YES;
//    [self.player setControlStyle: MPMovieControlStyleNone];
//    self.player.repeatMode = MPMovieRepeatModeOne;
//    [self.player.view setFrame:[UIScreen mainScreen].bounds];
//    self.player.view.alpha = 0;

    
    
     @end

