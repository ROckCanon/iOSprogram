//
//  MusicViewController.h
//  Music_Interface
//
//  Created by 尹键溶 on 2017/10/8.
//  Copyright © 2017年 TonyStark. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Song_info.h"
#import <AFNetworking.h>
#import <MJExtension.h>
@interface MusicViewController : UIViewController
@property(nonatomic,strong)NSString *Song_id;

-(instancetype)initWithSong_id:(NSString *)ID;
@end
