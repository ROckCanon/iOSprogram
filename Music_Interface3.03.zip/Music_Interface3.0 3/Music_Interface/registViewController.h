//
//  registViewController.h
//  Music_Interface
//
//  Created by TonyStark on 2017/9/29.
//  Copyright © 2017年 TonyStark. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MovieController.h"
#import "AppDelegate.h"
@interface registViewController :UIViewController

//@property(strong,nonatomic)UIView *registView;
//@property(strong,nonatomic)UIViewController *registControl;

@end
