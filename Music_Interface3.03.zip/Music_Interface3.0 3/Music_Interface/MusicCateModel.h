//
//  MusicCateModel.h
//  Home
//
//  Created by 尹键溶 on 2017/10/3.
//  Copyright © 2017年 st`. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MusicCateModel : NSObject
@property(nonatomic,strong)NSString *author;
@property(nonatomic,strong)NSString *title;
@property(nonatomic,strong)NSString *song_id;
@property(nonatomic,strong)NSString *pic_small;

@end
