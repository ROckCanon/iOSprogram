//
//  MusicView.m
//  Home
//
//  Created by 尹键溶 on 2017/10/3.
//  Copyright © 2017年 st`. All rights reserved.
//

#import "MusicView.h"
#import <AFNetworking.h>


@interface MusicView()<AVAudioPlayerDelegate>
//当前时长
@property (weak, nonatomic) IBOutlet UILabel *NowTime;

//滑动条
@property (weak, nonatomic) IBOutlet UISlider *Slider;

//点击播放
@property (weak, nonatomic) IBOutlet UIButton *ClickPlay;
//那条线
@property (weak, nonatomic) IBOutlet UIImageView *anchorImage;
//判断播放状态
@property(nonatomic,assign,getter=isPlaying)BOOL playing;

//定时器
@property(nonatomic,strong)CADisplayLink *singerTimer;

@end

@implementation MusicView

-(instancetype)initWithSong_id:(NSString *)ID{
    if(self = [super init]){
        MusicView *view = [[[NSBundle mainBundle]loadNibNamed:@"Empty" owner:self options:nil] lastObject];
        view.song_id = ID;
        return view;
    }
    return self;
};
+(instancetype)SongIDWithMusicView:(NSString *)ID{
    return [[self alloc]initWithSong_id:ID];
}


//加载xib文件时对其进行初始化
-(void)awakeFromNib{
    [super awakeFromNib];
    //让歌手图变成圆形
    self.singerImageView.layer.cornerRadius = 76;
    self.singerImageView.layer.masksToBounds = true;
    //改变其锚点
    self.anchorImage.layer.anchorPoint = CGPointMake(0.21, 0.15);
}
//播放时旋转
-(CADisplayLink*)singerTimer{
    if(_singerTimer == nil){
        _singerTimer = [CADisplayLink displayLinkWithTarget:self selector:@selector(refresh)];
        //加入主循环
        [_singerTimer addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
    }
    return _singerTimer;
}
-(void)refresh{
    //包括照片的旋转
    self.singerImageView.transform = CGAffineTransformRotate(self.singerImageView.transform, M_PI * 2 / 60 /5);
    //获取当前时间
    CMTime time = self.mymusic.currentTime;
    //获取秒数
    NSTimeInterval currrent = time.value / time.timescale;
    //转化为int
    NSString *str = [NSString stringWithFormat:@"%f",currrent];
    int T = [str intValue];
    self.NowTime.text = [NSString stringWithFormat:@"%02d:%02d",T/60,T%60];
    //滑动条的位置
    float AllTime = [self.Info.file_duration floatValue];
    self.Slider.value = T/AllTime;
}
//拖动滑动条所触发的事件
- (void)setSlider:(UISlider *)Slider{
    _Slider = Slider;
    Slider.continuous = NO;
    [_Slider addTarget:self action:@selector(ChangeMusicPlayTime) forControlEvents:UIControlEventValueChanged];
}
- (void)ChangeMusicPlayTime{
    CMTime duration = _mymusic.currentItem.asset.duration;
    // 歌曲总时间和当前时间
    Float64 completeTime = CMTimeGetSeconds(duration);
    Float64 currentTime = (Float64)(_Slider.value) * completeTime;
    
    //播放器定位到对应的位置
    CMTime targetTime = CMTimeMake((int64_t)(currentTime), 1);
    
    [_mymusic seekToTime:targetTime];
}
//点击开始/暂停按键
- (IBAction)ClickPlaying:(id)sender {
    if(self.isPlaying) [self StartPlay];
    else [self EndPlaying];
}
-(void)StartPlay{
    //状态切换为暂停播放
    self.playing = false;
    //改变图标样式
    UIImage *name = [UIImage imageNamed:@"cm2_fm_btn_play_prs"];
    [_ClickPlay setImage:name forState:UIControlStateNormal];
    //转盘停止旋转 即让定时器停止
    self.singerTimer.paused=true;
    //音乐停止播放
    [self.mymusic pause];
    //锚转回去
    [UIView animateWithDuration:1.0 animations:^{
        self.anchorImage.transform = CGAffineTransformRotate(self.anchorImage.transform, M_PI_4 * 0.4);
    }];

}
-(void)EndPlaying{
    //状态切换为开始播放
    self.playing = true;
    //改变图标样式
    //        self.ClickPlay.imageView.image = [UIImage imageNamed:@"cm2_fm_btn_pause_prs"];
    UIImage *name = [UIImage imageNamed:@"cm2_fm_btn_pause_prs"];
    [_ClickPlay setImage:name forState:UIControlStateNormal];
    //轮盘开始旋转
    self.singerTimer.paused = false;
    //音乐开始播放
    [self.mymusic play];
    //锚转过来
    [UIView animateWithDuration:1.0 animations:^{
        self.anchorImage.transform = CGAffineTransformRotate(self.anchorImage.transform, -M_PI_4 * 0.4);
    }];
}


@end
