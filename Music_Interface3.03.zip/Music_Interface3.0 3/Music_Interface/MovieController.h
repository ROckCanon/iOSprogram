//
//  MovieController.h
//  Music_Interface
//
//  Created by TonyStark on 2017/9/24.
//  Copyright © 2017年 TonyStark. All rights reserved.
//

#import <UIKit/UIKit.h>

@class registViewController;
//@class registViewController;

//typedef void(^registBlock)(registViewController *regist);

@interface MovieController :UIViewController
@property (strong,nonatomic) NSURL *sourceMobieURL;
@property(strong,nonatomic)UITextField *uernameTextField;
@property(strong,nonatomic)UITextField *passwordTextFied;
//@property(strong,nonatomic)RegistController *registCtrl;
//@property(nonatomic,copy)registBlock registBlock;



@end
