//
//  HeadImageModel.m
//  Home
//
//  Created by 尹键溶 on 2017/10/1.
//  Copyright © 2017年 st`. All rights reserved.
//

#import "HeadImageModel.h"

@implementation HeadImageModel
//-(void)initWithDic:(NSDictionary *)dic{
//    if(self=[super init]){
//        
//    }
//}
//+(void)
@end
