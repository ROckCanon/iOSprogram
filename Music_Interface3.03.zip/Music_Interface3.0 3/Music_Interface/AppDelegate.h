//
//  AppDelegate.h
//  Music_Interface
//
//  Created by TonyStark on 2017/9/23.
//  Copyright © 2017年 TonyStark. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVOSCloud/AVOSCloud.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong,nonatomic) UIWindow *window;


@end

