//
//  Song_info.h
//  Music_Interface
//
//  Created by 尹键溶 on 2017/10/9.
//  Copyright © 2017年 TonyStark. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Song_info : NSObject
//歌曲名字
@property(nonatomic,strong)NSString* album_title;
//播放时长
@property(nonatomic,strong) NSString *file_duration;
//歌曲链接
@property(nonatomic,strong) NSString *file_link;
//歌曲封面
@property(nonatomic,strong)NSString *pic_small;
//歌手名称
@property(nonatomic,strong)NSString *author;
@end
