//
//  MusicViewController.m
//  Music_Interface
//
//  Created by 尹键溶 on 2017/10/8.
//  Copyright © 2017年 TonyStark. All rights reserved.
//

#import "MusicViewController.h"
#import "MusicView.h"
@interface MusicViewController ()
@property(nonatomic,strong)__block AVPlayer *player;
@end

@implementation MusicViewController
-(instancetype)initWithSong_id:(NSString *)ID{
    if(self = [super init]){
        self.Song_id = ID;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    dispatch_queue_t queue = dispatch_queue_create("test.queue", DISPATCH_QUEUE_SERIAL);
    dispatch_sync(queue, ^{

        AFHTTPSessionManager *manager = [[AFHTTPSessionManager alloc]init];
        NSString *url = [NSString stringWithFormat:@"http://tingapi.ting.baidu.com/v1/restserver/ting?from=qianqian&version=2.1.0&method=baidu.ting.song.play&songid=%@",_Song_id];
        [manager GET:url parameters:nil progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            for(int i=0;i<10;i++){
                NSLog(@"%d",i);
            }
            //获取音乐
            NSDictionary *array = [responseObject objectForKey:@"bitrate"];
            NSURL *Music = [NSURL URLWithString:[array objectForKey:@"file_link"]];
            AVPlayerItem *item = [[AVPlayerItem alloc]initWithURL:Music];
            NSLog(@"1%@",_player);
            _player = [[AVPlayer alloc]initWithPlayerItem:item];
            NSLog(@"2%@",_player);
            
            //创建字典接收
            NSDictionary *array1 = [responseObject objectForKey:@"songinfo"];
            //创建模型
            Song_info *info = [[Song_info alloc]init];
            NSString *str = [NSString stringWithFormat:@"%@",[array objectForKey:@"file_duration"]];
            info.file_duration = str;
            info.file_link =[array objectForKey:@"file_link"];
            info.album_title = [array1 objectForKey:@"album_title"];
            info.pic_small = [array1 objectForKey:@"pic_small"];
            info.author = [array1 objectForKey:@"author"];
            //给view设值
            MusicView *view = [MusicView SongIDWithMusicView:self.Song_id];
            view.Info = info;
            view.SingerName.text = info.author;
            [view setMymusic:_player];
            
            //总时间进行特殊处理
            int Number = [info.file_duration intValue];
            view.MusicTime.text = [NSString stringWithFormat:@"%02d:%02d",Number/60,Number%60];
            
            view.singerImageView.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:info.pic_small]]];

            [self.view addSubview:view];
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            NSLog(@"%@",error);
        }];
    });
    
    
    NSLog(@"%@",self.Song_id);
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
