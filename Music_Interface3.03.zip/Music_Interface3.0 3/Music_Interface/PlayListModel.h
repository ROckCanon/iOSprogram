//
//  PlayListModel.h
//  Home
//
//  Created by 尹键溶 on 2017/10/2.
//  Copyright © 2017年 st`. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PlayListModel : NSObject
@property(nonatomic,strong)NSString* pic_300;
@property(nonatomic,strong)NSString*title;

@end
