//
//  NameSetting.m
//  Setting
//
//  Created by yhq on 2017/10/9.
//  Copyright © 2017年 yhq. All rights reserved.
//

#import "NameSetting.h"
#import "ViewController.h"

@interface NameSetting ()<UITableViewDelegate,UITableViewDataSource>

@end

@implementation NameSetting

- (void)viewDidLoad {
    [super viewDidLoad];
    UITableView *nameTV = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, 375, 667) style:UITableViewStyleGrouped];
    nameTV.delegate = self;
    nameTV.dataSource = self;
    [self.view addSubview:nameTV];
    self.view.backgroundColor = [UIColor whiteColor];
}




- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSInteger rows;
    if (section == 0) {
        rows = 1;
    }else{
        rows = 1;
    }
    
    return rows;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            cell.textLabel.text = @"添加账号";
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
             [tableView deselectRowAtIndexPath:indexPath animated:YES];
        }
    }
    if (indexPath.section == 1) {
        if (indexPath.row == 0) {
            cell.textLabel.text = @"联系客服";
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
        }
    }
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row == 0 && indexPath.section == 0) {
        ViewController *vc = [[ViewController alloc]init];
        UINavigationController *nvgt = [[UINavigationController alloc]initWithRootViewController:vc];
        [self.navigationController pushViewController:nvgt animated:YES];//这里有问题
       // [self.navigationController popViewControllerAnimated:];
      //  [self.navigationController popViewControllerAnimated:ni];
    }else if (indexPath.row == 0 && indexPath.section == 1){
        UIAlertController *callme = [UIAlertController alertControllerWithTitle:@"提示" message:@"确定拨打181-6330-8135吗？" preferredStyle:UIAlertControllerStyleAlert];
        [callme addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action)
                      
                           {NSLog(@"dianjiqueding");
            
                           }]];
        [callme addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
        [self presentViewController:callme animated:YES completion:nil];
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
    }
    
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
