//
//  SetController.m
//  Setting
//
//  Created by yhq on 2017/10/9.
//  Copyright © 2017年 yhq. All rights reserved.
//

#import "SetController.h"
#import "NameSetting.h"
#import "AssessController.h"
//#import "AboutController.h"

@interface SetController ()<UITableViewDataSource,UITableViewDelegate>

@end

@implementation SetController

- (void)viewDidLoad {
    [super viewDidLoad];
    UITableView *settable = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, 375, 667) style:UITableViewStyleGrouped];
    settable.backgroundColor = [UIColor whiteColor];
    settable.dataSource = self;
    settable.delegate =self;
    [self.view addSubview:settable];
    
   // self.view.backgroundColor = [UIColor yellowColor];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 3;
}

//每一组有多少行
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSInteger row = 0;
    if (section == 0) {
        row = 1;
    }else if (section == 1){
        row = 2;
    }else {
        row = 3;
    }
    return row;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    
    NSInteger sectionIndex = indexPath.section;
    NSInteger rowIndex = indexPath.row;
    if (sectionIndex == 0) {
        
        if (rowIndex == 0) {
            cell.textLabel.text = @"账号设置"; //00
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            [tableView deselectRowAtIndexPath:indexPath animated:YES]; //取消按钮点击，待修改
            
            
        }
    }else if (sectionIndex == 1){
        if (rowIndex == 0) {
            cell.textLabel.text = @"邀请好友";//10
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
          
            
        }else if (rowIndex == 1){
            cell.textLabel.text = @"赐我好评";//11
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            
        }
    }else if (sectionIndex == 2){
        if (rowIndex == 0) {
            cell.textLabel.text = @"当前版本";//20
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            
        }else if (rowIndex == 1){
            cell.textLabel.text = @"使用帮助";//21
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            
        }else if(rowIndex == 2){
            cell.textLabel.text = @"检查更新";//22
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
          
            
        }
    }
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 2 && indexPath.row == 2) {
        UIAlertController *alert1 = [UIAlertController alertControllerWithTitle:@"更新完成" message:@"现在已经是最新版本" preferredStyle:UIAlertControllerStyleAlert];
        [alert1 addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleCancel handler:nil]];
        [self presentViewController:alert1 animated:YES completion:nil];
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
    }else if (indexPath.section == 0 && indexPath.row == 0){
        NameSetting *nameSet = [[NameSetting alloc]init];
        //NSString *str = [NSString stringWithFormat:@"%d,%d",indexPath.section,];创建账号设置后再写
        [self.navigationController pushViewController:nameSet animated:YES];
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
        nameSet.title = @"用户";
    }else if (indexPath.section == 1 && indexPath.row == 0){
        UIAlertController *alert2 = [UIAlertController alertControllerWithTitle:@"提示" message:@"链接已经复制" preferredStyle:UIAlertControllerStyleAlert];
        [alert2 addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleCancel handler:nil]];
        [self presentViewController:alert2 animated:YES completion:nil];
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
    }else if (indexPath.section == 1 &&indexPath.row == 1){
        AssessController *assessCtrl = [[AssessController alloc]init];
        [self.navigationController pushViewController:assessCtrl animated:YES];
        assessCtrl.title = @"评价";
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
    }else if (indexPath.section == 2 && indexPath.row == 0){
        UIAlertController *alert3 = [UIAlertController alertControllerWithTitle:@"版本" message:@"当前版本号：3.1.1" preferredStyle:UIAlertControllerStyleAlert];
        [alert3 addAction:[UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleCancel handler:nil]];
        [self presentViewController:alert3 animated:YES completion:nil];
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
    }else if (indexPath.section == 2 &&indexPath.row == 1){
        UIViewController *aboutCtrl = [[UIViewController alloc]init];
        [self.navigationController pushViewController:aboutCtrl animated:YES];
        aboutCtrl.title = @"使用帮助";
        aboutCtrl.view.backgroundColor = [UIColor whiteColor];
        UILabel *about1 = [[UILabel alloc]initWithFrame:CGRectMake(120,100, 375, 100)];
        about1.text = @"使用帮助";
        UILabel *about2 = [[UILabel alloc]initWithFrame:CGRectMake(0, 110, 375, 400)];
        about2.text = @"        现如今音乐对于人们的生活密不可分，所以机会所有的电子设备上都有 播放音乐的功能下面对我们做的播放器做一个演示并且配有截图，显而易见，简单实用";
        about2.numberOfLines = 5;
        about1.font = [UIFont fontWithName:@"Helvetica" size:30.f];
        [aboutCtrl.view addSubview:about1];
        [aboutCtrl.view addSubview:about2];
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
    }
      
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
