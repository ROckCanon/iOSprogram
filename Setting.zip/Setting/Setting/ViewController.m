//
//  ViewController.m
//  Setting
//
//  Created by yhq on 2017/10/9.
//  Copyright © 2017年 yhq. All rights reserved.
//

#import "ViewController.h"
#import "SetController.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(100, 100, 50, 50)];
    button.backgroundColor = [UIColor blueColor];
    [self jumpToTheset];
    [self.view addSubview:button];
    [button addTarget:self action:@selector(jumpToTheset) forControlEvents:UIControlEventTouchUpInside];
    // Do any additional setup after loading the view, typically from a nib.
}


-(void)jumpToTheset{
    NSLog(@"jin ru la ");
    SetController *setCtrl = [[SetController alloc]init];
    [self.navigationController pushViewController:setCtrl animated:YES];
    setCtrl.title = @"setting";
    
//    UINavigationController *navg = [[UINavigationController alloc]initWithRootViewController:setCtrl];
    
    
}


@end
