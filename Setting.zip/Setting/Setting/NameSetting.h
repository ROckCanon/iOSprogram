//
//  NameSetting.h
//  Setting
//
//  Created by yhq on 2017/10/9.
//  Copyright © 2017年 yhq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NameSetting : UIViewController

@end
