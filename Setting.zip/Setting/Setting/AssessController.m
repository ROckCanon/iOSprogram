//
//  AssessController.m
//  Setting
//
//  Created by yhq on 2017/10/9.
//  Copyright © 2017年 yhq. All rights reserved.
//

#import "AssessController.h"
static int num;
@interface AssessController ()
@property(strong,nonatomic) UILabel *visionLabel;
//@property(strong,nonatomic)NSString *string;

@end

@implementation AssessController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIButton *goodBt = [[UIButton alloc]initWithFrame:CGRectMake( 40 + [UIScreen mainScreen].bounds.origin.x/3,200 , 50, 50)];
    UIImage *imagehao = [UIImage imageNamed:@"hao"];
    [goodBt setBackgroundImage:imagehao forState:UIControlStateNormal];
    UILabel *label1 = [[UILabel alloc]initWithFrame:CGRectMake(45 + [UIScreen mainScreen].bounds.origin.x/3,240 , 50, 50)];
    label1.text = @"好评";
    [self.view addSubview:label1];
    [self.view addSubview:goodBt];
    [goodBt addTarget:self action:@selector(onClick) forControlEvents:UIControlEventTouchUpInside];
    
    
    UIButton *middleBt = [[UIButton alloc]initWithFrame:CGRectMake( 160 + [UIScreen mainScreen].bounds.origin.x/3,200 , 50, 50)];
    UIImage *imagezhong = [UIImage imageNamed:@"zhong"];
    [middleBt setBackgroundImage:imagezhong forState:UIControlStateNormal];
    UILabel *label2 = [[UILabel alloc]initWithFrame:CGRectMake(165 + [UIScreen mainScreen].bounds.origin.x/3,240 , 50, 50)];
    label2.text = @"中评";
    [self.view addSubview:label2];
    [self.view addSubview:middleBt];
    
    UIButton *badBt = [[UIButton alloc]initWithFrame:CGRectMake( 280 + [UIScreen mainScreen].bounds.origin.x/3,200 , 50, 50)];
    UIImage *imagebad = [UIImage imageNamed:@"cha"];
    [badBt setBackgroundImage:imagebad forState:UIControlStateNormal];
    UILabel *label3 = [[UILabel alloc]initWithFrame:CGRectMake(285 + [UIScreen mainScreen].bounds.origin.x/3,240 , 50, 50)];
    label3.text = @"差评";
    [self.view addSubview:label3];
    [self.view addSubview:badBt];
    
   // UILabel *lable0  = [[UILabel alloc]initWithFrame:CGRectMake(300, 300, 100, 100)];
//    lable0.text = [NSString stringWithFormat:@"%d",num];
//     [self.view addSubview:lable0];
//    self.string = lable0.text;
//    self.visionLabel.text = self.string;
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.visionLabel = [[UILabel alloc]initWithFrame:CGRectMake(230, 300, 100, 100)];
    [self.view addSubview:self.visionLabel];
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(30, 300, 300, 100)];
    label.text = @"感谢您的好评，已经收到          好评";
    [self.view addSubview:label];
   // lable0.text = [NSString stringWithFormat:@"%d",num];
   // [self.view addSubview:lable0];
}

-(void)onClick{
    NSLog(@"hao ping la");
    self.visionLabel.text = [NSString stringWithFormat:@"%d",num];
    num ++;
    
   // self.visionLabel.text = [NSString stringWithFormat:@"%d",num];
   
    NSLog(@"%d",num);
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
