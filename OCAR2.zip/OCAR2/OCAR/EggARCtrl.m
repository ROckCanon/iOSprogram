//
//  EggARCtrl.m
//  OCAR
//
//  Created by Apple on 2018/8/23.
//  Copyright © 2018年 Apple. All rights reserved.
//

#import "EggARCtrl.h"
#import <ChameleonFramework/Chameleon.h>

@interface EggARCtrl ()<ARSCNViewDelegate>
@property (weak, nonatomic) IBOutlet ARSCNView *eggAr;

@property(nonatomic,strong)SCNView *scnView;

@end

@implementation EggARCtrl

- (void)viewDidLoad {
    [super viewDidLoad];
    

    // Do any additional setup after loading the view.
    
    self.eggAr.delegate = self;
    
    // Show statistics such as fps and timing information
    
    self.eggAr.showsStatistics = YES;
    
    // Create a new scene
    SCNScene *scene = [SCNScene sceneNamed:@"art.scnassets/ask.scn"];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(70,550,250,60);
    //关键语句
    button.layer.cornerRadius = 10.0;//2.0是圆角的弧度，根据需求自己更改
    button.layer.borderColor = [UIColor randomFlatColor].CGColor;//设置边框颜色
    button.layer.borderWidth = 3.0f;//设置边框颜色
    [button setTitle:@"收集" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(tapTest) forControlEvents:UIControlEventTouchUpInside];
    [self.eggAr addSubview:button];
//    SCNView *scnView = [[SCNView alloc]initWithFrame:CGRectMake(0, 0, 375, 667)];
//    [self.view addSubview:scnView];
//    scnView.scene = scene;
//    scnView.allowsCameraControl = YES;
//    scnView.showsStatistics = YES;
////    scnView.backgroundColor = [UIColor clearColor];
//    self.scnView = scnView;
//    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapTest:)];
//    [scnView addGestureRecognizer:tap];
    // Set the scene to the view
    
    self.eggAr.scene = scene;
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    // Create a session configuration
    ARWorldTrackingConfiguration *configuration = [ARWorldTrackingConfiguration new];
    
    // Run the view's session
    [self.eggAr.session runWithConfiguration:configuration];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    // Pause the view's session
    [self.eggAr.session pause];
}
-(void)tapTest{

    UIAlertController *confirmCtrl = [UIAlertController alertControllerWithTitle:@"隐藏的拼图" message:@"你可找到我了" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *act1=[UIAlertAction actionWithTitle:@"添加到收藏" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    UIAlertAction *act2=[UIAlertAction actionWithTitle:@"不用加入" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    [confirmCtrl addAction:act1];
    [confirmCtrl addAction:act2];
    [self presentViewController:confirmCtrl animated:YES completion:^{
        
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
