//
//  cocoModel.m
//  OCAR
//
//  Created by Apple on 2018/8/23.
//  Copyright © 2018年 Apple. All rights reserved.
//

#import "cocoModel.h"

@interface cocoModel ()<ARSCNViewDelegate>
@property (weak, nonatomic) IBOutlet ARSCNView *cocoSCNView;

@property(nonatomic, strong)SCNView *scnView;
@end

@implementation cocoModel

- (void)viewDidLoad {
    [super viewDidLoad];
    self.cocoSCNView.delegate = self;
    
    // Show statistics such as fps and timing information
    self.cocoSCNView.showsStatistics = YES;
    
    // Create a new scene
    SCNScene *scene = [SCNScene sceneNamed:@"art.scnassets/kunkka_model.scn"];
    
    SCNView *scnView = [[SCNView alloc]initWithFrame:CGRectMake(0,0, 375,667)];
    [self.view addSubview:scnView];
    scnView.scene = scene;
    scnView.allowsCameraControl = YES;
    scnView.showsStatistics = YES;
    self.scnView = scnView;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapTest:)];
    [scnView addGestureRecognizer:tap];
    //    scnView.backgroundColor = [UIColor ]
    
    // Set the scene to the view
    self.cocoSCNView.scene = scene;
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)tapTest:(UITapGestureRecognizer *)tap{
    SCNVector3 projectedOrigin = [self.cocoSCNView projectPoint:SCNVector3Zero];
    CGPoint vp = [tap locationInView:self.cocoSCNView];
    SCNVector3 vpWithZ = SCNVector3Make(vp.x, vp.y, projectedOrigin.z);
    SCNVector3 worldPoint = [self.cocoSCNView unprojectPoint:vpWithZ];
    NSLog(@"x: --- %f y: --- %f z: --- %f", worldPoint.x, worldPoint.y, worldPoint.z);
    
    UIAlertController *confirmCtrl = [UIAlertController alertControllerWithTitle:@"恭喜你拼凑成功" message:@"是否收藏？" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *act1=[UIAlertAction actionWithTitle:@"加入图鉴" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    UIAlertAction *act2=[UIAlertAction actionWithTitle:@"不用加入" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    [confirmCtrl addAction:act1];
    [confirmCtrl addAction:act2];
    [self presentViewController:confirmCtrl animated:YES completion:^{
        
    }];
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    // Create a session configuration
    ARWorldTrackingConfiguration *configuration = [ARWorldTrackingConfiguration new];
    
    // Run the view's session
    [self.cocoSCNView.session runWithConfiguration:configuration];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
