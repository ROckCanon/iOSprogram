//
//  MapViewCtrl.m
//  OCAR
//
//  Created by Apple on 2018/8/23.
//  Copyright © 2018年 Apple. All rights reserved.
//

#import "MapViewCtrl.h"
#import <QuartzCore/QuartzCore.h>
#import <ChameleonFramework/Chameleon.h>
#import "homePageCtrl.h"
#import "ShowAdd.h"

@interface MapViewCtrl ()<UIGestureRecognizerDelegate>
@property(nonatomic,strong)UILabel *titleLabel;
@property(nonatomic,strong)UIWebView *webView;
@end

@implementation MapViewCtrl

- (void)viewDidLoad {
    [super viewDidLoad];
    UIImage *rightImage = [[UIImage imageNamed:@"小彩蛋"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    self.navigationItem.rightBarButtonItem.image = rightImage;
    self.titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, 1, 30)];
    self.titleLabel.backgroundColor = [UIColor clearColor];
    self.titleLabel.font = [UIFont boldSystemFontOfSize:18];
    self.titleLabel.textColor = [UIColor colorWithRed:242 green:242 blue:242 alpha:1];
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.titleLabel.font = [UIFont systemFontOfSize:12];
    self.titleLabel.numberOfLines = 2;
    self.titleLabel.text = [NSString stringWithFormat:@"累计步数\n4500步"];
    self.navigationItem.titleView = self.titleLabel;
   
//    UIBarButtonItem *barBtn1=[[UIBarButtonItem alloc] initWithImage:rightImage style:UIBarButtonItemStylePlain target:self action:nil];
////
//    self.navigationItem.rightBarButtonItem = barBtn1;
//    barBtn1.image.renderingMode = UIImageRenderingModeAlwaysOriginal
    
    _webView = [[UIWebView alloc]initWithFrame:CGRectMake(0, 0, 375, 667)];
    _webView.userInteractionEnabled = YES;
    self.view = _webView;
//    webView.backgroundColor = [UIColor blueColor];
    NSString *htmlPath = [[[NSBundle mainBundle]bundlePath]stringByAppendingPathComponent:@"index.html"];
    
    [_webView loadRequest:[NSURLRequest requestWithURL:[NSURL fileURLWithPath:htmlPath]]];
    self.navigationController.navigationBar.barTintColor = [UIColor flatMagentaColorDark];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    
    for (int i = 0; i<30; i++) {
        UIImageView *imageView = [[UIImageView alloc]initWithFrame:CGRectMake(rand() % 375, rand() % 667, 30, 30)];
        imageView.image = [UIImage imageNamed:@"egg"];
        [_webView addSubview:imageView];
    }
    // Do any additional setup after loading the view.
    UIButton *addBtn = [[UIButton alloc]initWithFrame:CGRectMake(150, 630, 90, 80)];
    [addBtn setImage:[UIImage imageNamed:@"加号"] forState:UIControlStateNormal];
    [addBtn addTarget:self action:@selector(showTheAdd) forControlEvents:UIControlEventTouchUpInside];
    [_webView addSubview:addBtn];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(test)];
    tap.delegate = self;
    [_webView addGestureRecognizer:tap];
//    UIToolbar *toolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, 375, 667)];
//    toolbar.barStyle = UIBarStyleBlackTranslucent;
//    toolbar.tag = 2000;
//    [_webView addSubview:toolbar];
//    toolbar.alpha = 0;
    UIBlurEffect *blur = [UIBlurEffect effectWithStyle:UIBlurEffectStyleLight];
    UIVisualEffectView *effectview = [[UIVisualEffectView alloc] initWithEffect:blur];
    effectview.frame = CGRectMake(0, 0, 375, 667);
    effectview.tag = 2000;
    effectview.alpha = 0;
    [_webView addSubview:effectview];
    ShowAdd *showView = [[ShowAdd alloc]initWithFrame:CGRectMake(70, 350, 90, 110)];
//    showView.backgroundColor = [UIColor whiteColor];
    showView.tag = 1000;
    showView.alpha = 0.0;
    [_webView addSubview:showView];
//    UITapGestureRecognizer *tap2 = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(test2)];
//    [showView addGestureRecognizer:tap2];
}
//-(void)jumpToMore{
//    homePageCtrl *homePage = [[homePageCtrl alloc]init];
//    [self.navigationController pushViewController:homePage animated:YES];
//}
//-(BOOL)prefersStatusBarHidden{
//    return YES;
//}
//- (void)navigationController:(UINavigationController*)navigationController willShowViewController:(UIViewController*)viewController animated:(BOOL)animated{
//    if(viewController == self){
//        [navigationController setNavigationBarHidden:YES animated:YES];
//    }else{
//        if ([navigationController isKindOfClass:[UIImagePickerController class]]) {
//            return;
//        }
//        [navigationController setNavigationBarHidden:NO animated:YES];
//        if(navigationController.delegate == self){
//            navigationController.delegate = nil;
//        }
//    }
//}
//-(void)viewWillAppear:(BOOL)animated{
//    [super viewWillAppear:animated];
//    self.navigationController.delegate = self;
//}
-(void)showTheAdd{
    NSLog(@"点击neibu");
    [UIView animateWithDuration:0.5 animations:^{
        UIView *view = [self.view viewWithTag:1000];
        UIView *view2 = [self.view viewWithTag:2000];
        view.alpha = 1.0;
        view2.alpha = 0.6;
        [self.webView layoutIfNeeded];
    }];
}
- (void)test{
    NSLog(@"点击web了");
    //改变透明度即可实现效果
    [UIView animateWithDuration:0.5 animations:^{
        UIView *view = [self.view viewWithTag:1000];
        view.alpha = 0.0;
        UIView *view2 = [self.view viewWithTag:2000];
        view2.alpha = 0.0;
        self.webView.alpha = 1.0;
        [self.webView layoutIfNeeded];
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer {
    return YES;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
