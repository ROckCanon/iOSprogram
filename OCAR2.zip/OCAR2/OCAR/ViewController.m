//
//  ViewController.m
//  OCAR
//
//  Created by Apple on 2018/8/22.
//  Copyright © 2018年 Apple. All rights reserved.
//

#import "ViewController.h"
#import <ChameleonFramework/Chameleon.h>


//#import "Chameleon.h"

@interface ViewController () <ARSCNViewDelegate>

@property (nonatomic, strong) IBOutlet ARSCNView *sceneView;

@property(nonatomic, strong)SCNView *scnView;

@end

    
@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(70,550,250,60);
    //关键语句
    button.layer.cornerRadius = 10.0;//2.0是圆角的弧度，根据需求自己更改
    button.layer.borderColor = [UIColor randomFlatColor].CGColor;//设置边框颜色
    button.layer.borderWidth = 3.0f;//设置边框颜色
    [button setTitle:@"收集" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(tapTest) forControlEvents:UIControlEventTouchUpInside];
    [self.sceneView addSubview:button];
    
    // Set the view's delegate
    self.sceneView.delegate = self;
    
    // Show statistics such as fps and timing information
    self.sceneView.showsStatistics = YES;
    
    // Create a new scene
    SCNScene *scene = [SCNScene sceneNamed:@"art.scnassets/iOS17vox.scn"];
    
//    SCNView *scnView = [[SCNView alloc]initWithFrame:CGRectMake(0,0, 375,667)];
//    [self.view addSubview:scnView];
//    scnView.scene = scene;
//    scnView.allowsCameraControl = YES;
//    scnView.showsStatistics = YES;
//    self.scnView = scnView;
//    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapTest:)];
//    [scnView addGestureRecognizer:tap];
    
    
//    scnView.backgroundColor = [UIColor ]
    
    // Set the scene to the view
    self.sceneView.scene = scene;
//    self.view.backgroundColor = [UIColor flatGreenDarkColor];
}

-(void)tapTest{
//    SCNVector3 projectedOrigin = [self.sceneView projectPoint:SCNVector3Zero];
//    CGPoint vp = [tap locationInView:self.sceneView];
//    SCNVector3 vpWithZ = SCNVector3Make(vp.x, vp.y, projectedOrigin.z);
//    SCNVector3 worldPoint = [self.sceneView unprojectPoint:vpWithZ];
//    NSLog(@"x: --- %f y: --- %f z: --- %f", worldPoint.x, worldPoint.y, worldPoint.z);
    
    UIAlertController *confirmCtrl = [UIAlertController alertControllerWithTitle:@"恭喜你拼凑成功" message:@"是否收藏？" preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *act1=[UIAlertAction actionWithTitle:@"加入图鉴" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    UIAlertAction *act2=[UIAlertAction actionWithTitle:@"不用加入" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    [confirmCtrl addAction:act1];
    [confirmCtrl addAction:act2];
    [self presentViewController:confirmCtrl animated:YES completion:^{
        
    }];
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    // Create a session configuration
    ARWorldTrackingConfiguration *configuration = [ARWorldTrackingConfiguration new];

    // Run the view's session
    [self.sceneView.session runWithConfiguration:configuration];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    // Pause the view's session
    [self.sceneView.session pause];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Release any cached data, images, etc that aren't in use.
}

#pragma mark - ARSCNViewDelegate

/*
// Override to create and configure nodes for anchors added to the view's session.
- (SCNNode *)renderer:(id<SCNSceneRenderer>)renderer nodeForAnchor:(ARAnchor *)anchor {
    SCNNode *node = [SCNNode new];
 
    // Add geometry to the node...
 
    return node;
}
*/

- (void)session:(ARSession *)session didFailWithError:(NSError *)error {
    // Present an error message to the user
    
}

- (void)sessionWasInterrupted:(ARSession *)session {
    // Inform the user that the session has been interrupted, for example, by presenting an overlay
    
}

- (void)sessionInterruptionEnded:(ARSession *)session {
    // Reset tracking and/or remove existing anchors if consistent tracking is required
    
}

@end
