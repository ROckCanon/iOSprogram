//
//  ShowAdd.m
//  OCAR
//
//  Created by Apple on 2018/8/25.
//  Copyright © 2018年 Apple. All rights reserved.
//

#import "ShowAdd.h"

@implementation ShowAdd
-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    self = [[[NSBundle mainBundle] loadNibNamed:@"show" owner:self options:nil] lastObject];
    if (self) {
        self.frame = frame;
    }
    return self;
    
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
