//
//  CollectCtrl.m
//  OCAR
//
//  Created by Apple on 2018/8/24.
//  Copyright © 2018年 Apple. All rights reserved.
//

#import "CollectCtrl.h"
#import "PhotoCtrl.h"
#define PIC_WIDTH 70

#define PIC_HEIGHT 80

#define COL_COUNT 3
@interface CollectCtrl ()
@property(nonatomic,strong)NSArray *picArr;

@end

@implementation CollectCtrl

- (void)viewDidLoad {
    [super viewDidLoad];
//    [self loadImage];
    [self addPictures];
    self.view.backgroundColor = [UIColor colorWithRed:102.0/255 green:45.0/255 blue:145.0/255 alpha:1];
    // Do any additional setup after loading the view.
}
//-(void)loadImage{
//    NSMutableArray *picArray = [NSMutableArray array];
//    for (int i = 0; i<18; i++) {
//
//    }
//}
-(void)addPictures{
    for (int i = 0; i< 12; i++) {
        UIImageView *imageView = [[UIImageView alloc]init];
//        imageView.backgroundColor = [UIColor ];
        imageView.layer.cornerRadius = 10.0f;
        imageView.layer.masksToBounds = YES;
        if (i == 0) {
            imageView.image = [UIImage imageNamed:@"iOS.png"];
            imageView.userInteractionEnabled = YES;
            UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapView:)];
            [imageView addGestureRecognizer:tap];
        }else{
        imageView.image = [UIImage imageNamed:@"ask.png"];
        }
        NSInteger row = i / COL_COUNT;
        // 图片所在列
        NSInteger col = i % COL_COUNT;
        // 间距
        CGFloat margin = (self.view.bounds.size.width - (PIC_WIDTH * COL_COUNT)) / (COL_COUNT + 1);
        // PointX
        CGFloat picX = margin + (PIC_WIDTH + margin) * col;
        // PointY
        CGFloat picY = margin + (PIC_HEIGHT + margin) * row;
        
        imageView.frame = CGRectMake(picX, picY + 100, PIC_WIDTH, PIC_HEIGHT);
        [self.view addSubview:imageView];
    }
}
-(void)tapView:(UITapGestureRecognizer *)sender{
    NSLog(@"ice");
    PhotoCtrl *photo = [[PhotoCtrl alloc]init];
    [self.navigationController pushViewController:photo animated:YES];
//    ViewController *vc = [[ViewController alloc]init];
//    vc.view.backgroundColor = [UIColor whiteColor];
//    [self.navigationController pushViewController:vc animated:YES];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
