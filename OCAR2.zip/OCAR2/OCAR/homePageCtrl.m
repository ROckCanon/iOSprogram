//
//  homePageCtrl.m
//  OCAR
//
//  Created by Apple on 2018/8/23.
//  Copyright © 2018年 Apple. All rights reserved.
//

#import "homePageCtrl.h"
#import <ChameleonFramework/Chameleon.h>

@interface homePageCtrl ()<UINavigationControllerDelegate>
//@property (weak, nonatomic) IBOutlet UILabel *numberLb;
@property (weak, nonatomic) IBOutlet UIButton *EggBtn;

@end

@implementation homePageCtrl

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor colorWithRed:102.0/255 green:45.0/255 blue:145.0/255 alpha:1];
    // Do any additional setup after loading the view.
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
//- (void)navigationController:(UINavigationController*)navigationController willShowViewController:(UIViewController*)viewController animated:(BOOL)animated{
//    if(viewController == self){
//        [navigationController setNavigationBarHidden:YES animated:YES];
//    }else{
//        if ([navigationController isKindOfClass:[UIImagePickerController class]]) {
//            return;
//        }
//    [navigationController setNavigationBarHidden:NO animated:YES];
//     if(navigationController.delegate == self){
//         navigationController.delegate = nil;
//     }
//}
//}
//-(void)viewWillAppear:(BOOL)animated{
//     [super viewWillAppear:animated];
//    self.navigationController.delegate = self;
//}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
