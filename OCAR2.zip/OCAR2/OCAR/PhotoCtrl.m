//
//  PhotoCtrl.m
//  OCAR
//
//  Created by Apple on 2018/8/24.
//  Copyright © 2018年 Apple. All rights reserved.
//

#import "PhotoCtrl.h"
#import <ChameleonFramework/Chameleon.h>

@interface PhotoCtrl ()<ARSCNViewDelegate>

@property(nonatomic,strong)ARSCNView *sceneView;

@end

@implementation PhotoCtrl

- (void)viewDidLoad {
    [super viewDidLoad];
    _sceneView = [[ARSCNView alloc]initWithFrame:CGRectMake(0, 0, 375, 667)];
    _sceneView.backgroundColor = [UIColor clearColor];
    self.sceneView.delegate = self;
    
    // Show statistics such as fps and timing information
    self.sceneView.showsStatistics = YES;
    // Do any additional setup after loading the view.
    SCNScene *scene = [SCNScene sceneNamed:@"art.scnassets/iOS17vox.scn"];
    
    self.sceneView.scene = scene;
    [self.view addSubview:_sceneView];
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = CGRectMake(70,550,250,60);
    //关键语句
    button.layer.cornerRadius = 10.0;//2.0是圆角的弧度，根据需求自己更改
    button.layer.borderColor = [UIColor randomFlatColor].CGColor;//设置边框颜色
    button.layer.borderWidth = 3.0f;//设置边框颜色
    [button setTitle:@"拍摄" forState:UIControlStateNormal];
    [button addTarget:self action:@selector(takePhoto) forControlEvents:UIControlEventTouchUpInside];
    [self.sceneView addSubview:button];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    // Create a session configuration
    ARWorldTrackingConfiguration *configuration = [ARWorldTrackingConfiguration new];
    
    // Run the view's session
    [self.sceneView.session runWithConfiguration:configuration];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    
    // Pause the view's session
    [self.sceneView.session pause];
}
-(void)takePhoto{
    NSLog(@"拍照");
    UIWindow *screenWindow = [[UIApplication sharedApplication]keyWindow];
    UIGraphicsBeginImageContext(screenWindow.frame.size);
    [screenWindow.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIImage* viewImage =UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    UIImageWriteToSavedPhotosAlbum(viewImage,nil,nil,nil);
    
//    UIGraphicsBeginImageContext(self.sceneView.bounds.size);
//    UIImage *image= UIGraphicsGetImageFromCurrentImageContext();
//    UIGraphicsEndImageContext();
//    NSLog(@"image:%@",image);
//    UIImageView *imaView = [[UIImageView alloc] initWithImage:image];
//    imaView.frame = CGRectMake(0, 700, 500, 500);
//    [_sceneView addSubview:imaView];
//    UIImageWriteToSavedPhotosAlbum(image, self, nil, nil);
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
